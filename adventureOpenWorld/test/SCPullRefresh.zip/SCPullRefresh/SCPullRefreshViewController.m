//
//  SCPullRefreshViewController.m
//  v2ex-iOS
//
//  Created by Singro on 4/4/14.
//  Copyright (c) 2014 Singro. All rights reserved.
//

#import "SCPullRefreshViewController.h"

#import "SCAnimationView.h"

static CGFloat const kRefreshHeight = 44.0f;

@interface SCPullRefreshViewController ()

@property (nonatomic, strong) UIView *tableHeaderView;
@property (nonatomic, strong) UIView *tableFooterView;

@property (nonatomic, strong) SCAnimationView *refreshView;
@property (nonatomic, strong) SCAnimationView *loadMoreView;

@property (nonatomic, assign) BOOL isLoadingMore;
@property (nonatomic, assign) BOOL isRefreshing;

@property (nonatomic, assign) BOOL hadLoadMore;

@end

@implementation SCPullRefreshViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.isLoadingMore = NO;
        self.isRefreshing = NO;
        self.hadLoadMore = NO;
        
        _viewShowing = NO;
        
    }
    return self;
}

- (void)loadView {
    [super loadView];
    
    self.tableHeaderView = [[UIView alloc] initWithFrame:(CGRect){0, 0, 320, 0}];
    self.refreshView = [[SCAnimationView alloc] initWithFrame:(CGRect){0, -44, 320, 44}];
    self.refreshView.timeOffset = 0.0;
    [self.tableHeaderView addSubview:self.refreshView];

    self.tableFooterView = [[UIView alloc] initWithFrame:(CGRect){0, 0, 320, 0}];
    self.loadMoreView = [[SCAnimationView alloc] initWithFrame:(CGRect){0, 0, 320, 44}];
    self.loadMoreView.timeOffset = 0.0;
    [self.tableFooterView addSubview:self.loadMoreView];

    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
//    _viewShowing = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReceiveStatusBarTappedNotification) name:kStatusBarTappedNotification object:nil];

}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kStatusBarTappedNotification object:nil];
//    _viewShowing = NO;
}

- (void)dealloc {
    
//    [[NSNotificationCenter defaultCenter] removeObserver:self];
//    NSLog(@"[super dealloc]");
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void)scrollViewDidScroll:(UIScrollView *)scrollView {

    // Refresh
    CGFloat offsetY = -scrollView.contentOffsetY - 64;
//    NSLog(@"offset: %.f", offsetY);

    self.refreshView.timeOffset = MAX(offsetY / 60.0, 0);
    
    
    // LoadMore
    if ((self.loadMoreBlock && scrollView.contentSizeHeight > 300) || !self.hadLoadMore) {
        self.loadMoreView.hidden = NO;
    } else {
        self.loadMoreView.hidden = YES;
    }
    
    if (scrollView.contentSizeHeight + scrollView.contentInsetTop < kScreenHeight) {
        return;
    }
    //    CGFloat loadMoreOffset = scrollView.contentOffsetY;
    CGFloat loadMoreOffset = - (scrollView.contentSizeHeight - self.view.height - scrollView.contentOffsetY + scrollView.contentInsetBottom);
    
    //    NSLog(@"offset         %.f", loadMoreOffset);
    //    NSLog(@"content height:         %.f", scrollView.contentSizeHeight);
    //    NSLog(@"content insert top: %.f  bottom: %.f", scrollView.contentInsetTop, scrollView.contentInsetBottom);
//    NSLog(@"loadMoreOffsetY:  %.f", loadMoreOffset);

    if (loadMoreOffset > 0) {
        self.loadMoreView.timeOffset = MAX(loadMoreOffset / 60.0, 0);
    } else {
        self.loadMoreView.timeOffset = 0;
    }
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    
    // Refresh
    CGFloat refreshOffset = -scrollView.contentOffsetY - scrollView.contentInsetTop;
    if (refreshOffset > 60 && self.refreshBlock && !self.isRefreshing) {
        [self beginRefresh];
    }
//    NSLog(@"refreshOffset:  %.f", refreshOffset);

    // loadMore
    CGFloat loadMoreOffset = scrollView.contentSizeHeight - self.view.height - scrollView.contentOffsetY + scrollView.contentInsetBottom;
    if (loadMoreOffset < -60 && self.loadMoreBlock && !self.isLoadingMore && scrollView.contentSizeHeight > kScreenHeight) {
        [self beginLoadMore];
    }
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    
}

#pragma mark - Public Methods

- (void)setRefreshBlock:(void (^)())refreshBlock {
    _refreshBlock = refreshBlock;
    
    if (self.tableView) {
        self.tableView.tableHeaderView = self.tableHeaderView;
    }
    
}

- (void)beginRefresh {
    
    [self.refreshView beginRefreshing];
    
    self.isRefreshing = YES;
    
    self.refreshBlock();
    [UIView animateWithDuration:0.2 animations:^{
        self.tableView.contentInsetTop = kRefreshHeight + 64;
    }];
    
}

- (void)endRefresh {
    
    [self.refreshView endRefreshing];
    
    self.isRefreshing = NO;
    
    [UIView animateWithDuration:0.5 animations:^{
        self.tableView.contentInsetTop = 64;
    }];

}

- (void)beginLoadMore {
    
    [self.loadMoreView beginRefreshing];
    
    self.isLoadingMore = YES;
    self.hadLoadMore = YES;
    
    self.loadMoreBlock();
    [UIView animateWithDuration:0.2 animations:^{
        self.tableView.contentInsetBottom = kRefreshHeight;
    }];
    
    
}

- (void)endLoadMore {
    
    [self.loadMoreView endRefreshing];
    
    self.isLoadingMore = NO;
    
    [UIView animateWithDuration:0.2 animations:^{
        self.tableView.contentInsetBottom = 0;
    }];
    
}

- (void)setLoadMoreBlock:(void (^)())loadMoreBlock {
    _loadMoreBlock = loadMoreBlock;
    
    if (self.loadMoreBlock && self.tableView) {
        self.tableView.tableFooterView = self.tableFooterView;
    }
    
}

#pragma mark - Notifications

- (void)didReceiveStatusBarTappedNotification {
    
    [self.tableView scrollRectToVisible:(CGRect){0, 0, 320, 0.1} animated:YES];

}

@end
